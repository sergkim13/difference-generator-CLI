# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['gendiff', 'gendiff.gendiff_format', 'gendiff.scripts']

package_data = \
{'': ['*']}

install_requires = \
['PyYAML>=6.0,<7.0']

entry_points = \
{'console_scripts': ['gendiff = gendiff.scripts.gendiff_script:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': "Second project from Hexlet's Python course",
    'long_description': '# Difference generator CLI\n\n### Hexlet tests and linter status:\n[![Actions Status](https://github.com/sergkim13/python-project-50/workflows/hexlet-check/badge.svg)](https://github.com/sergkim13/python-project-50/actions)\n[![Actions Status](https://github.com/sergkim13/python-project-50/actions/workflows/project_ci.yml/badge.svg)](https://github.com/sergkim13/python-project-50/actions/workflows/project_ci.yml)[![Maintainability](https://api.codeclimate.com/v1/badges/4b548ad9dd2986338109/maintainability)](https://codeclimate.com/github/sergkim13/python-project-50/maintainability)[![Test Coverage](https://api.codeclimate.com/v1/badges/4b548ad9dd2986338109/test_coverage)](https://codeclimate.com/github/sergkim13/python-project-50/test_coverage)\n\n\n### Installation\n1. Make sure you have Poetry installed on your computer.\nIf you have not, type:\n\'\'\'curl -sSL https://install.python-poetry.org | python3 -\'\'\' (works for Linux, macOS, Windows (WSL))\nSee https://python-poetry.org/docs/ for more info about Poetry.\n2. Clone repository:\n``$ git clone https://github.com/sergkim13/python-project-50.git``\n2. Type: \n\'\'\'make install-gendiff\'\'\'\n\n\n### Description:\nThis CLI-utility compares two \'\'\'JSON\'\'\' or \'\'\'YAML\'\'\' files and shows a difference. You can set a format of output: \'stylish\' mode (set by default) , \'plain\' mode or \'json\' mode.\nInput "gendiff -h" for more information.\n______________\n### Описание:\nДанная консольная утилита сравнивает между собой два файла формата \'\'\'JSON\'\'\' или \'\'\'YAML\'\'\' и показывает разницу между ними. Вы можете настроить формат вывода результата: \'stylish\' (выбран по умолчанию), \'plain\' или \'json\'.\nНаберите "gendiff -h", чтобы узнать больше.\n\n### Manual:\n**To compare files in the terminal, type:**  \n>```$ gendiff <path1>  <path2>```\n\n1. -**h, --help** - ```$ gendif -h``` - shows a guide;\n2. **-f, --format** - ```$ gendif -f``` - allows you to select the format of the \ndifference output. **Available formats:**\n  \n   1. `-f stylish`- default form. Example output:\n  \n   >{\n    - follow: false\n      host: hexlet.io\n    - proxy: 123.234.53.22\n    - timeout: 50\n    + timeout: 20\n    + verbose: true\n    }\n    2. `-f plain`. Example output:  \n  \n    > Property \'common.follow\' was added with value: false  \n    Property \'common.setting2\' was removed  \n    Property \'common.setting3\' was updated. From true to [complex value]  \n    Property \'common.setting4\' was added with value: \'blah blah\'\n    3. `-f json`. Returns the difference in json format.\n  \n    >{"-follow": false, "=host": "hexlet.io", "-proxy": "123.234.53.22", "-timeout": 50, "+timeout": 20, "+verbose": true}\n______________\n### Инструкция\n\n**Чтобы сравнить два файла, наберите в консоли:**  \n>```$ gendiff <путь_к_файлу_1>  <путь_к_файлу_2>```\n\n1. -**h, --help** - ```$ gendif -h``` - вывод справочной информации;\n2. **-f, --format** - ```$ gendif -f``` - позволяет выбрать формат формат вывода. **Available formats:**\n  \n   1. `-f stylish`- по умолчанию. Пример:\n  \n   >{\n    - follow: false\n      host: hexlet.io\n    - proxy: 123.234.53.22\n    - timeout: 50\n    + timeout: 20\n    + verbose: true\n    }\n    2. `-f plain`. Пример:  \n  \n    > Property \'common.follow\' was added with value: false  \n    Property \'common.setting2\' was removed  \n    Property \'common.setting3\' was updated. From true to [complex value]  \n    Property \'common.setting4\' was added with value: \'blah blah\'\n    3. `-f json`. Возвращает результат в формате \'\'\'json\'\'\'.\n  \n    >{"-follow": false, "=host": "hexlet.io", "-proxy": "123.234.53.22", "-timeout": 50, "+timeout": 20, "+verbose": true}\n\n#### Demo in \'stylish\' mode.\n[![asciicast](https://asciinema.org/a/Q6PH9m3bcVfdljH6yPOqRNnq7.svg)](https://asciinema.org/a/Q6PH9m3bcVfdljH6yPOqRNnq7)\n\n#### Demo in \'plain\' mode.\n[![asciicast](https://asciinema.org/a/TZc0azdhkC8ruBZH5mKyuP4IC.svg)](https://asciinema.org/a/TZc0azdhkC8ruBZH5mKyuP4IC)\n\n#### Demo in \'json\' mode.\n[![asciicast](https://asciinema.org/a/a6u4PCgb7ZzavIvc1natUaHwE.svg)](https://asciinema.org/a/a6u4PCgb7ZzavIvc1natUaHwE)',
    'author': 'Sergey Kim',
    'author_email': '<sergkim7@gmail.com>',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
